# ClubConnect

A responsive, front-end Club Membership Management System built using HTML, CSS and JavaScript.

## Run the project
1. Extract `ClubConnect.zip`.
2. Open the `ClubConnect` folder in Visual Studio Code.
3. Install the **Live Server** extension (Ritwick Dey), if it is not installed.
4. Right-click `index.html` and choose **Open with Live Server**.

## Demo admin login
- Email: `admin@clubconnect.demo`
- Password: `Admin123`

## Student login
Use **Create account** on the sign-in screen to register a student account.

## Included features
- Student registration and login
- Role-based student and admin views
- Student dashboard and club discovery
- Search clubs and filter by category
- Membership request submission
- Admin approval/rejection workflow
- Membership status tracking
- Notifications
- Admin club create, edit and delete
- Member directory
- Dashboard statistics and reports
- CSV export
- Responsive layout for mobile and desktop

## Important project note
This is a browser-based academic prototype. It stores demo data in the browser's Local Storage. It does not provide secure production authentication or a shared database across different devices/browsers. Do not use real passwords or sensitive personal data. For a production system, a secure backend and database are required.

## Reset demo data
In the browser, open Developer Tools → Application/Storage → Local Storage, then delete the `clubconnect_v1` entry and refresh the page. The demo data will be seeded again.


ROLE-BASED DEMO LOGINS
----------------------
Admin:
Email: admin@clubconnect.demo
Password: Admin123

Student:
Email: student@clubconnect.demo
Password: Student123

Member:
Email: member@clubconnect.demo
Password: Member123

ROLE WORKFLOW
- A newly registered account starts as Student.
- Students can explore clubs and submit membership requests.
- Admin reviews requests and approves or rejects them.
- Once a request is approved, that account is promoted to Member.
- Members can view their approved memberships and notifications.
- The login form includes a role selector and quick demo-role buttons.
