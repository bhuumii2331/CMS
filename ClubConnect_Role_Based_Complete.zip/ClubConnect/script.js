const $ = (id) => document.getElementById(id);
const STORAGE_KEY = "clubconnect_v1";
const ADMIN = { id: "admin-001", name: "ClubConnect Admin", email: "admin@clubconnect.demo", password: "Admin123", role: "admin" };
const seedClubs = [
  {id:"c1",name:"Coding & Tech Club",category:"Technology",symbol:"⌘",color:"tech",description:"Build, experiment and solve real-world problems with fellow tech enthusiasts.",members:128},
  {id:"c2",name:"Music Society",category:"Arts & Culture",symbol:"♫",color:"music",description:"Find your rhythm through performances, jam sessions and music workshops.",members:94},
  {id:"c3",name:"Dance Collective",category:"Arts & Culture",symbol:"✧",color:"dance",description:"Express yourself, learn new styles and perform with a high-energy crew.",members:86},
  {id:"c4",name:"Photography Club",category:"Creative",symbol:"◎",color:"photo",description:"Capture campus stories, learn visual storytelling and explore creative projects.",members:73},
  {id:"c5",name:"Entrepreneurship Cell",category:"Business",symbol:"↗",color:"business",description:"Turn bold ideas into action with startup talks, challenges and peer learning.",members:112},
  {id:"c6",name:"Literary Circle",category:"Literature",symbol:"✎",color:"lit",description:"Share stories, debate ideas and celebrate the written and spoken word.",members:61},
  {id:"c7",name:"Sports & Fitness Club",category:"Sports",symbol:"◉",color:"sports",description:"Bring your energy to friendly competitions, fitness activities and team events.",members:145},
  {id:"c8",name:"Eco & Social Impact",category:"Community",symbol:"♧",color:"eco",description:"Create positive change through sustainability drives and community initiatives.",members:58}
];
let db, currentUser = null, currentPage = "overview", toastTimer;
function loadDB(){
  try { db = JSON.parse(localStorage.getItem(STORAGE_KEY)); } catch(e){ db = null; }
  if(!db || !Array.isArray(db.users) || !Array.isArray(db.clubs)){
    db = {users:[ADMIN],clubs:seedClubs.map(x=>({...x})),memberships:[],notifications:[]};
    saveDB();
  }
  if(!db.users.some(u=>u.email===ADMIN.email)) db.users.push(ADMIN);
  const demoStudent = {id:"demo-student",name:"Aarav Student",email:"student@clubconnect.demo",password:"Student123",role:"student"};
  const demoMember = {id:"demo-member",name:"Mira Member",email:"member@clubconnect.demo",password:"Member123",role:"member"};
  if(!db.users.some(u=>u.email===demoStudent.email)) db.users.push(demoStudent);
  if(!db.users.some(u=>u.email===demoMember.email)) db.users.push(demoMember);
  if(!db.memberships.some(m=>m.userId===demoMember.id && m.status==="approved")){
    const firstClub = db.clubs[0];
    if(firstClub) db.memberships.push({id:"demo-membership-001",userId:demoMember.id,clubId:firstClub.id,status:"approved",date:new Date().toISOString()});
  }
  saveDB();
}
function saveDB(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(db)); }
function esc(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function toast(msg,error=false){const t=$("toast");t.textContent=msg;t.classList.toggle("error",error);t.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove("show"),2600);}
function initials(name="U"){return name.trim().split(/\s+/).slice(0,2).map(x=>x[0]).join("").toUpperCase();}
function dateText(d){return new Date(d).toLocaleDateString(undefined,{day:"numeric",month:"short",year:"numeric"});}
function statusPill(s){return `<span class="status status-${s}">${s[0].toUpperCase()+s.slice(1)}</span>`;}
function membershipsFor(userId){return db.memberships.filter(m=>m.userId===userId);}
function unreadCount(){return db.notifications.filter(n=>n.userId===currentUser.id&&!n.read).length;}
function notify(userId,title,message){db.notifications.unshift({id:"n"+Date.now()+Math.random(),userId,title,message,date:new Date().toISOString(),read:false});}
function setAuthMode(mode){
  const login=mode==="login";$("loginForm").classList.toggle("hidden",!login);$("registerForm").classList.toggle("hidden",login);
  $("loginTab").classList.toggle("active",login);$("registerTab").classList.toggle("active",!login);
  $("authTitle").textContent=login?"Sign in to ClubConnect":"Create your account";
  $("authSubtitle").textContent=login?"Your next campus chapter starts here.":"Join a community that shares your interests.";
}
function showApp(){
  $("authView").classList.add("hidden");$("appView").classList.remove("hidden");
  $("sidebarName").textContent=currentUser.name;$("sidebarRole").textContent=currentUser.role==="admin"?"Administrator":currentUser.role==="member"?"Club member":"Student account";
  $("sidebarAvatar").textContent=initials(currentUser.name);$("topAvatar").textContent=initials(currentUser.name);
  $("studentNav").classList.toggle("hidden",currentUser.role==="admin");$("adminNav").classList.toggle("hidden",currentUser.role!=="admin");
  $("todayLabel").textContent=new Date().toLocaleDateString(undefined,{weekday:"short",day:"numeric",month:"short",year:"numeric"});
  updateBadges();goTo(currentUser.role==="admin"?"admin-overview":"overview");
}
function showAuth(){currentUser=null;$("appView").classList.add("hidden");$("authView").classList.remove("hidden");setAuthMode("login");}
function updateBadges(){
  const unread=unreadCount();$("notifBadge").textContent=unread;$("notifBadge").classList.toggle("hidden",!unread);
  const pending=db.memberships.filter(m=>m.status==="pending").length;$("applicationBadge").textContent=pending;$("applicationBadge").classList.toggle("hidden",!pending);
}
function goTo(page){
  currentPage=page;document.querySelectorAll(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  $("pageCrumb").textContent=({overview:"Overview",explore:"Explore clubs",myclubs:"My memberships",notifications:"Notifications","admin-overview":"Overview","admin-applications":"Applications","admin-clubs":"Manage clubs","admin-members":"Members","admin-reports":"Reports"})[page]||"Overview";
  $("sidebar").classList.remove("open");
  const renderers={"overview":renderOverview,"explore":renderExplore,"myclubs":renderMyClubs,"notifications":renderNotifications,"admin-overview":renderAdminOverview,"admin-applications":renderApplications,"admin-clubs":renderAdminClubs,"admin-members":renderMembers,"admin-reports":renderReports};
  (renderers[page]||renderOverview)();
}
function heading(eyebrow,title,subtitle,actions=""){return `<div class="page-heading"><div><span class="eyebrow dark-eyebrow">${eyebrow}</span><h1>${title}</h1><p>${subtitle}</p></div><div class="heading-actions">${actions}</div></div>`;}
function stat(label,value,icon,foot){return `<div class="stat-card"><div class="stat-top"><span>${label}</span><span class="stat-icon">${icon}</span></div><div class="stat-number">${value}</div><div class="stat-foot">${foot}</div></div>`;}
function clubCard(c,showAction=true){
  const mine=currentUser?membershipsFor(currentUser.id).find(m=>m.clubId===c.id):null;
  const action=mine?`<button class="btn btn-outline" disabled>${mine.status==="approved"?"Member":mine.status==="pending"?"Request pending":"Previously rejected"}</button>`:`<button class="btn btn-primary" onclick="applyClub('${c.id}')">Join club <span>→</span></button>`;
  return `<article class="club-card"><div class="club-cover ${esc(c.color||"tech")}"><span class="club-symbol">${esc(c.symbol||"✦")}</span><span class="club-category">${esc(c.category)}</span></div><div class="club-card-body"><h4>${esc(c.name)}</h4><p>${esc(c.description)}</p><div class="club-meta"><span>♙ ${Number(c.members||0)} members</span><span>Campus community</span></div>${showAction?`<div class="club-card-actions">${action}</div>`:""}</div></article>`;
}
function renderOverview(){
  const mine=membershipsFor(currentUser.id),approved=mine.filter(m=>m.status==="approved").length,pending=mine.filter(m=>m.status==="pending").length;
  const clubs=db.clubs.slice(0,3);
  $("pageContent").innerHTML=heading("STUDENT WORKSPACE","Your campus, your community",`Welcome back, ${esc(currentUser.name.split(" ")[0])}. Here's what's happening in your club journey.`)+
  `<div class="welcome-strip"><div><span class="eyebrow">YOUR NEXT CHAPTER STARTS HERE</span><h2>Make room for what moves you.</h2><p>Explore communities, meet like-minded people and get involved.</p></div><button class="btn" onclick="goTo('explore')">Explore clubs &nbsp; →</button></div>
  <div class="stats-grid">${stat("Available clubs",db.clubs.length,"▣","Communities to explore")}${stat("My memberships",approved,"♙","Approved memberships")}${stat("Pending requests",pending,"◷","Awaiting admin review")}${stat("Notifications",unreadCount(),"♧","Unread updates")}</div>
  <div class="section-head"><h3>Discover something new</h3><button class="text-link" onclick="goTo('explore')">View all clubs →</button></div><div class="club-grid">${clubs.map(c=>clubCard(c)).join("")}</div>`;
}
function renderExplore(){
  $("pageContent").innerHTML=heading("FIND YOUR COMMUNITY","Explore clubs","Browse campus communities and find the right space for your interests.")+
  `<div class="search-row"><div class="search-wrap"><span>⌕</span><input class="form-control" id="clubSearch" placeholder="Search clubs by name or keyword..."></div><select class="form-control" id="categoryFilter"><option value="">All categories</option>${[...new Set(db.clubs.map(c=>c.category))].sort().map(x=>`<option>${esc(x)}</option>`).join("")}</select></div><div class="club-grid" id="exploreGrid">${db.clubs.map(c=>clubCard(c)).join("")}</div>`;
  $("clubSearch").addEventListener("input",filterClubs);$("categoryFilter").addEventListener("change",filterClubs);
}
function filterClubs(){const q=$("clubSearch").value.toLowerCase(),cat=$("categoryFilter").value;const list=db.clubs.filter(c=>(c.name+" "+c.description+" "+c.category).toLowerCase().includes(q)&&(!cat||c.category===cat));$("exploreGrid").innerHTML=list.length?list.map(c=>clubCard(c)).join(""):`<div class="empty-state"><div class="empty-icon">⌕</div><h3>No clubs found</h3><p>Try another search or category.</p></div>`;}
function applyClub(id){
  const existing=membershipsFor(currentUser.id).find(m=>m.clubId===id);
  if(existing&&existing.status!=="rejected"){toast("You already have an active request for this club.");return;}
  const club=db.clubs.find(c=>c.id===id);if(!club)return;
  const m={id:"m"+Date.now(),userId:currentUser.id,clubId:id,status:"pending",date:new Date().toISOString()};
  db.memberships.push(m);notify(currentUser.id,"Application submitted",`Your request to join ${club.name} has been submitted.`);saveDB();updateBadges();toast("Membership request submitted!");goTo(currentPage);
}
function renderMyClubs(){
  const list=membershipsFor(currentUser.id).map(m=>({...m,club:db.clubs.find(c=>c.id===m.clubId)})).filter(x=>x.club);
  $("pageContent").innerHTML=heading("YOUR COMMUNITIES","My memberships","Track your club applications and approved memberships.")+
  `<div class="table-panel"><div class="table-scroll"><table><thead><tr><th>Club</th><th>Applied on</th><th>Status</th></tr></thead><tbody>${list.map(x=>`<tr><td><strong>${esc(x.club.name)}</strong><br><span class="muted">${esc(x.club.category)}</span></td><td>${dateText(x.date)}</td><td>${statusPill(x.status)}</td></tr>`).join("")}</tbody></table></div>${!list.length?`<div class="empty-state"><div class="empty-icon">▣</div><h3>No memberships yet</h3><p>Explore clubs and send your first membership request.</p><br><button class="btn btn-primary" onclick="goTo('explore')">Explore clubs</button></div>`:""}</div>`;
}
function renderNotifications(){
  const list=db.notifications.filter(n=>n.userId===currentUser.id);list.forEach(n=>n.read=true);saveDB();updateBadges();
  $("pageContent").innerHTML=heading("STAY IN THE LOOP","Notifications","Updates about your membership applications and club activity.")+
  `<div class="notification-list">${list.length?list.map(n=>`<div class="notification-item"><div class="notification-icon">♧</div><div><strong>${esc(n.title)}</strong><p>${esc(n.message)}</p><small>${dateText(n.date)}</small></div></div>`).join(""):`<div class="panel empty-state"><div class="empty-icon">♧</div><h3>You're all caught up</h3><p>New updates will appear here.</p></div>`}</div>`;
}
function adminStats(){const approved=db.memberships.filter(m=>m.status==="approved").length;return {students:db.users.filter(u=>u.role==="student").length,clubs:db.clubs.length,pending:db.memberships.filter(m=>m.status==="pending").length,approved};}
function renderAdminOverview(){
  const s=adminStats(),recent=db.memberships.slice().sort((a,b)=>new Date(b.date)-new Date(a.date)).slice(0,5);
  $("pageContent").innerHTML=heading("ADMIN WORKSPACE","Campus overview","A clear view of your clubs, members and incoming applications.",`<button class="btn btn-primary" onclick="openClubModal()">＋ Add a club</button>`)+
  `<div class="stats-grid">${stat("Registered students",s.students,"♙","Student accounts")}${stat("Active clubs",s.clubs,"▣","Managed communities")}${stat("Pending applications",s.pending,"◷","Need your attention")}${stat("Approved memberships",s.approved,"✓","Successful joins")}</div>
  <div class="section-head"><h3>Recent applications</h3><button class="text-link" onclick="goTo('admin-applications')">View all →</button></div>
  <div class="table-panel"><div class="table-scroll"><table><thead><tr><th>Student</th><th>Club</th><th>Applied on</th><th>Status</th></tr></thead><tbody>${recent.map(m=>{const u=db.users.find(x=>x.id===m.userId),c=db.clubs.find(x=>x.id===m.clubId);return `<tr><td><strong>${esc(u?.name||"Unknown")}</strong><br><span class="muted">${esc(u?.email||"")}</span></td><td>${esc(c?.name||"Deleted club")}</td><td>${dateText(m.date)}</td><td>${statusPill(m.status)}</td></tr>`}).join("")}</tbody></table></div>${!recent.length?`<div class="empty-state"><h3>No applications yet</h3><p>Student requests will appear here.</p></div>`:""}</div>`;
}
function renderApplications(){
  const list=db.memberships.slice().sort((a,b)=>new Date(b.date)-new Date(a.date));
  $("pageContent").innerHTML=heading("MEMBERSHIP WORKFLOW","Applications","Review student requests and update their membership status.")+
  `<div class="search-row"><div class="search-wrap"><span>⌕</span><input class="form-control" id="appSearch" placeholder="Search student or club..."></div><select class="form-control" id="appStatus"><option value="">All statuses</option><option>pending</option><option>approved</option><option>rejected</option></select></div><div class="table-panel"><div class="table-scroll"><table><thead><tr><th>Student</th><th>Club</th><th>Applied on</th><th>Status</th><th>Actions</th></tr></thead><tbody id="applicationsBody"></tbody></table></div></div>`;
  $("appSearch").addEventListener("input",filterApplications);$("appStatus").addEventListener("change",filterApplications);filterApplications();
}
function filterApplications(){
  const q=$("appSearch").value.toLowerCase(),status=$("appStatus").value;
  const list=db.memberships.filter(m=>{const u=db.users.find(x=>x.id===m.userId),c=db.clubs.find(x=>x.id===m.clubId);return ((u?.name||"")+" "+(u?.email||"")+" "+(c?.name||"")).toLowerCase().includes(q)&&(!status||m.status===status);});
  $("applicationsBody").innerHTML=list.length?list.map(m=>{const u=db.users.find(x=>x.id===m.userId),c=db.clubs.find(x=>x.id===m.clubId);return `<tr><td><div class="member-cell"><span class="mini-avatar">${initials(u?.name||"?")}</span><span><strong>${esc(u?.name||"Unknown")}</strong><br><span class="muted">${esc(u?.email||"")}</span></span></div></td><td>${esc(c?.name||"Deleted club")}</td><td>${dateText(m.date)}</td><td>${statusPill(m.status)}</td><td>${m.status==="pending"?`<div class="table-actions"><button class="small-btn small-approve" onclick="updateApplication('${m.id}','approved')">Approve</button><button class="small-btn small-reject" onclick="updateApplication('${m.id}','rejected')">Reject</button></div>`:`<span class="muted">Reviewed</span>`}</td></tr>`}).join(""):`<tr><td colspan="5"><div class="empty-state"><h3>No applications found</h3><p>Try changing the filters.</p></div></td></tr>`;
}
function updateApplication(id,status){
  const m=db.memberships.find(x=>x.id===id);if(!m)return;m.status=status;
  const c=db.clubs.find(x=>x.id===m.clubId);const u=db.users.find(x=>x.id===m.userId);
  const applicant=db.users.find(x=>x.id===m.userId);
  if(status==="approved"&&c){c.members=(c.members||0)+1;if(applicant)applicant.role="member";}
  if(status==="rejected"&&applicant&&!db.memberships.some(x=>x.userId===m.userId&&x.status==="approved"))applicant.role="student";
  notify(m.userId,`Membership ${status}`,`Your request to join ${c?.name||"the club"} was ${status}.`);
  saveDB();updateBadges();toast(`Application ${status}.`);renderApplications();
}
function renderAdminClubs(){
  $("pageContent").innerHTML=heading("CLUB DIRECTORY","Manage clubs","Create, update and remove campus club listings.",`<button class="btn btn-primary" onclick="openClubModal()">＋ Add a club</button>`)+
  `<div class="table-panel"><div class="table-scroll"><table><thead><tr><th>Club</th><th>Category</th><th>Members</th><th>Description</th><th>Actions</th></tr></thead><tbody>${db.clubs.map(c=>`<tr><td><strong>${esc(c.name)}</strong></td><td>${esc(c.category)}</td><td>${Number(c.members||0)}</td><td>${esc(c.description.slice(0,65))}${c.description.length>65?"…":""}</td><td><div class="table-actions"><button class="small-btn small-edit" onclick="openClubModal('${c.id}')">Edit</button><button class="small-btn small-reject" onclick="deleteClub('${c.id}')">Delete</button></div></td></tr>`).join("")}</tbody></table></div>${!db.clubs.length?`<div class="empty-state"><h3>No clubs created</h3><p>Add your first campus club.</p></div>`:""}</div>`;
}
function openClubModal(id=null){
  const c=id?db.clubs.find(x=>x.id===id):null;$("modalTitle").textContent=c?"Edit club":"Add a new club";
  $("modalBody").innerHTML=`<form class="modal-form" id="clubForm"><label>Club name<input name="name" required maxlength="55" value="${esc(c?.name||"")}" placeholder="e.g. Robotics Club"></label><label>Category<select name="category" required>${["Technology","Arts & Culture","Creative","Business","Literature","Sports","Community","Other"].map(x=>`<option ${c?.category===x?"selected":""}>${x}</option>`).join("")}</select></label><label>Short description<textarea name="description" required maxlength="180" placeholder="What is this club about?">${esc(c?.description||"")}</textarea></label><label>Club symbol<input name="symbol" maxlength="3" value="${esc(c?.symbol||"✦")}" placeholder="✦"></label><button class="btn btn-primary" type="submit">${c?"Save changes":"Create club"}</button></form>`;
  $("modalBackdrop").classList.remove("hidden");
  $("clubForm").addEventListener("submit",e=>{e.preventDefault();const f=new FormData(e.target),data={name:f.get("name").trim(),category:f.get("category"),description:f.get("description").trim(),symbol:f.get("symbol").trim()||"✦"};if(c)Object.assign(c,data);else db.clubs.push({id:"c"+Date.now(),...data,color:"tech",members:0});saveDB();closeModal();toast(c?"Club updated.":"Club created.");renderAdminClubs();});
}
function deleteClub(id){
  const c=db.clubs.find(x=>x.id===id);if(!c)return;if(!confirm(`Delete "${c.name}"? Related membership records will also be removed.`))return;
  db.clubs=db.clubs.filter(x=>x.id!==id);db.memberships=db.memberships.filter(x=>x.clubId!==id);saveDB();toast("Club deleted.");renderAdminClubs();
}
function renderMembers(){
  const approved=db.memberships.filter(m=>m.status==="approved");
  const rows=approved.map(m=>{const u=db.users.find(x=>x.id===m.userId),c=db.clubs.find(x=>x.id===m.clubId);return {u,c,m};}).filter(x=>x.u&&x.c);
  $("pageContent").innerHTML=heading("CAMPUS COMMUNITY","Members","View students with approved club memberships.")+
  `<div class="search-row"><div class="search-wrap"><span>⌕</span><input class="form-control" id="memberSearch" placeholder="Search members, email or club..."></div></div><div class="table-panel"><div class="table-scroll"><table><thead><tr><th>Student</th><th>Club</th><th>Member since</th><th>Membership status</th></tr></thead><tbody id="membersBody"></tbody></table></div></div>`;
  $("memberSearch").addEventListener("input",()=>renderMemberRows(rows));renderMemberRows(rows);
}
function renderMemberRows(rows){const q=$("memberSearch").value.toLowerCase(),filtered=rows.filter(x=>(x.u.name+" "+x.u.email+" "+x.c.name).toLowerCase().includes(q));$("membersBody").innerHTML=filtered.length?filtered.map(x=>`<tr><td><div class="member-cell"><span class="mini-avatar">${initials(x.u.name)}</span><span><strong>${esc(x.u.name)}</strong><br><span class="muted">${esc(x.u.email)}</span></span></div></td><td>${esc(x.c.name)}</td><td>${dateText(x.m.date)}</td><td>${statusPill("approved")}</td></tr>`).join(""):`<tr><td colspan="4"><div class="empty-state"><h3>No members found</h3><p>Approved memberships will appear here.</p></div></td></tr>`;}
function renderReports(){
  const s=adminStats(),counts={};db.clubs.forEach(c=>counts[c.name]=db.memberships.filter(m=>m.clubId===c.id&&m.status==="approved").length);
  const max=Math.max(1,...Object.values(counts));
  $("pageContent").innerHTML=heading("INSIGHTS & ANALYTICS","Reports","A snapshot of membership activity across your campus.")+
  `<div class="stats-grid">${stat("Total students",s.students,"♙","Registered accounts")}${stat("Total clubs",s.clubs,"▣","Available communities")}${stat("Approved requests",s.approved,"✓","Confirmed memberships")}${stat("Pending requests",s.pending,"◷","Awaiting review")}</div>
  <div class="report-grid"><div class="panel"><h3>Memberships by club</h3><div class="bar-list">${Object.entries(counts).map(([name,n])=>`<div class="bar-row"><span>${esc(name.length>17?name.slice(0,17)+"…":name)}</span><div class="bar-track"><div class="bar-fill" style="width:${n/max*100}%"></div></div><strong>${n}</strong></div>`).join("")||`<p class="muted">No club data available.</p>`}</div></div>
  <div class="panel"><h3>Application status</h3><div class="donut-wrap"><div class="donut" style="background:conic-gradient(#4169e1 0 ${db.memberships.length? s.approved/db.memberships.length*100:0}%,#e7ebf5 0 100%)"><strong>${db.memberships.length}</strong></div><div class="legend"><span>Approved: ${s.approved}</span><span>Other: ${db.memberships.length-s.approved}</span></div></div><p class="muted" style="text-align:center;font-size:9px">Total membership applications</p></div></div>
  <div class="section-head"><h3>Export report data</h3></div><div class="panel"><p class="muted" style="font-size:11px;margin-top:0">Download a CSV summary of membership applications for spreadsheet analysis.</p><button class="btn btn-primary" onclick="exportCSV()">↓ &nbsp; Export applications CSV</button></div>`;
}
function exportCSV(){
  const rows=[["Student","Email","Club","Category","Applied On","Status"],...db.memberships.map(m=>{const u=db.users.find(x=>x.id===m.userId),c=db.clubs.find(x=>x.id===m.clubId);return [u?.name||"",u?.email||"",c?.name||"",c?.category||"",dateText(m.date),m.status];})];
  const csv=rows.map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(",")).join("\n");
  const blob=new Blob([csv],{type:"text/csv;charset=utf-8;"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download="clubconnect-membership-report.csv";a.click();URL.revokeObjectURL(url);toast("CSV report exported.");
}
function closeModal(){$("modalBackdrop").classList.add("hidden");}
$("loginTab").addEventListener("click",()=>setAuthMode("login"));$("registerTab").addEventListener("click",()=>setAuthMode("register"));
function useDemo(role){
  const demos={
    admin:{email:"admin@clubconnect.demo",password:"Admin123"},
    student:{email:"student@clubconnect.demo",password:"Student123"},
    member:{email:"member@clubconnect.demo",password:"Member123"}
  };
  const demo=demos[role];if(!demo)return;
  $("loginEmail").value=demo.email;$("loginPassword").value=demo.password;$("loginRole").value=role;
  $("loginForm").requestSubmit();
}
$("loginForm").addEventListener("submit",e=>{e.preventDefault();const email=$("loginEmail").value.trim().toLowerCase(),pass=$("loginPassword").value,selectedRole=$("loginRole").value;const user=db.users.find(u=>u.email.toLowerCase()===email&&u.password===pass);if(!user){toast("Email or password is incorrect.",true);return;}if(selectedRole!=="auto"&&user.role!==selectedRole){toast("This account does not have the selected role. Choose the correct role.",true);return;}currentUser=user;showApp();});
$("registerForm").addEventListener("submit",e=>{e.preventDefault();const name=$("regName").value.trim(),email=$("regEmail").value.trim().toLowerCase(),password=$("regPassword").value;if(db.users.some(u=>u.email.toLowerCase()===email)){toast("An account with this email already exists.",true);return;}const user={id:"u"+Date.now(),name,email,password,role:"student"};db.users.push(user);saveDB();currentUser=user;showApp();toast("Welcome to ClubConnect! Your account is ready.");});
$("logoutButton").addEventListener("click",showAuth);$("closeModal").addEventListener("click",closeModal);$("modalBackdrop").addEventListener("click",e=>{if(e.target===$("modalBackdrop"))closeModal();});
$("mobileMenu").addEventListener("click",()=>$("sidebar").classList.toggle("open"));
document.querySelectorAll(".nav-link").forEach(b=>b.addEventListener("click",()=>goTo(b.dataset.page)));
$("profileButton").addEventListener("click",()=>toast(`${currentUser.name} · ${currentUser.role}`));
$("topAvatar").addEventListener("click",()=>toast(`${currentUser.name} · ${currentUser.role}`));
loadDB();$("authClubCount").textContent=String(db.clubs.length).padStart(2,"0");
